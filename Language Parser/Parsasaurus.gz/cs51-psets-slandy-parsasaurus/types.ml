(******************************************************************************

Filename: types.ml

Authors: Brooke Carter, Alec Guzov, Stephen Landy, and Dan Zangri

Description: Contains the definitions for all of the types used in the program

******************************************************************************)

(* The basic unit within the grammars are symbols, which are defined
   as strings                                                                *)
type symbol = string

(* An item is the basic unit within each state of the finite-state machine
   and consists of a nonterminal left-hand side that corresponds to one or
   more symbols, which are split into a pre and post, which are separated
   by where the cursor currently is positioned                               *)
type item = {lhs: symbol; pre: symbol list; post: symbol list}


(* This section defines the grammar map to be a map with symbols as its key  *)
module OrderedGramPair =
  struct
    type t = symbol
    let compare t1 t2 = String.compare t1 t2
  end ;;
    
module GramMap = Map.Make (OrderedGramPair);;

(* This section defines states to be sets of items                           *)
module Items =
  struct
    type t = item
    let compare item1 item2 =
      let t1,t2 = item1.lhs,item2.lhs in
        let x = String.compare t1 t2 in 
        if x <> 0 then x
        else 
          if item1.pre < item2.pre then -1 
          else if item2.pre < item1.pre then 1
          else 
            if item1.post < item2.post then -1 
            else if item2.post < item1.post then 1 
            else 0
  end

module State = Set.Make(Items);;

(* This function defines a data structure that represents sets of states     *)
module States = 
  struct
    type t = State.t
    let compare t1 t2 = State.compare t1 t2
  end

module StateSet = Set.Make(States);;


(* A trans is the structure used by the lookup table to signify which state
   to go to in the finite-state machine based on the current state and
   symbol                                                                    *)
type trans = State.t * State.t * symbol
