(******************************************************************************

Filename: parsasaurus.ml

Authors: Brooke Carter, Alec Guzov, Stephen Landy, and Dan Zangri

Description: 1) Defines wrapper function for reading in input, 2) creates 
    finite state machine from input string using the build.ml file, and 3) 
    prints the reduction items along with the structure of the parsed input
    string

******************************************************************************)

open Types
open Print
open Build
open Ptree

(* This variable stores the string from the command line that contains the 
   name of the filename of the text file that contains the grammar.         *)
let filename : string =
  try Sys.argv.(1)
  with Invalid_argument _ ->
    print_string "\nFilename where grammar is located: " ; read_line ()

(* This function takes in the string that contains the name of the text file
    that contains the grammar and returns the grammar map for the 
    corresponding grammar.                                                   *)
let rec get_grammar (filename: string) : 'a GramMap.t =
  try 
    create_map filename
  with
    | Sys_error grammar -> 
      print_string "No such file or directory.\n\nEnter another filename: " ;
      get_grammar (read_line ())
    | Failure f -> 
      print_string (f^"\n\nEnter another filename: ") ;
      get_grammar (read_line ())

let grammar = get_grammar filename
let (state1,s,ts) = build_lookup grammar

(* This variable stores the string from the command line that contains the
   input string that should be parsed.                                      *)
let input =
  try Sys.argv.(2)
  with Invalid_argument _ -> 
    print_string "\nInput string (no quotes): " ; read_line ()

(* This wrapper function runs continuously when the program is started so
    that the grammar does not need to be re-mapped every time that a new
    sentence is fed to the parser                                           *)
let rec parse (input: string) : unit =
  
(* This function takes a string and returns a list of strings that are
   between the spaces in the input string                                   *)
  let to_parse = split " " input in

(* This portion checks whether the input has nonterminal symbols and then
   checks with the user if this was intended                                *)
  if List.exists (fun s -> not (is_terminal s)) to_parse then (
    print_string "Input contains non-terminal symbols in the provided grammar.
                  \nParse anyway? (y/n) " ;
    let reply = read_line () in
    let rec proceed yn =
      if yn = "n" then (
        print_string "\nNew input string: " ; parse (read_line ()))
      else if yn <> "y" then (
        print_string "Please respond with 'y' or 'n': " ; 
        proceed (read_line ()))
    in proceed reply) ;

(* This function takes a symbol list and an integer n and returns the
   symbol list with n elements removed from the front.                       *)
  let rec sublist (lst : symbol list) (n : int) : symbol list =
    if n=0 then lst
    else 
      match lst with
        | hd::tl -> sublist tl (n-1)
        | [] -> lst
  in

(* This function takes a list and returns the unique elements of the list
   in a new list.                                                           *)
  let rec unique (lst : 'a list) : 'a list = 
    match lst with
      | [] -> []
      | hd :: tl -> if List.mem hd tl then unique tl else hd :: (unique tl)
  in

(* This function checks whether the input state has an item that requires a
   reduction and then returns a list of the elements in that set as options
   that indicate whether the item requires a reduction.                     *)
  let accepting_state (s : State.t) : ((State.elt*int) option) list = 
    let lst = State.elements s in
    List.map (fun i ->
      if i.post=[] then Some (i, List.length i.pre)
      else None) lst
  in

(* This function takes a state as its input that is assumed to be
   unambiguous (i.e. not have more than one item that requires a reduction
   and only one item in the state in that case) and returns an option that 
   indicates if the state has an option that needs to be reduced.           *)
  let unamb_accepting_state (s : State.t) : (item*int) option = 
    List.fold_right (fun i r -> 
      if i.post = [] then Some (i, List.length i.pre) 
      else r) (State.elements s) None
  in

(* This function takes a list of options from a state that is returned
   by accepting state and indicates whether the state is ambigious (i.e.
   the state has at least one item that needs to be reduced and at least
   one other item)                                                          *)
  let is_ambiguous (lst : ((State.elt*int) option) list) : bool = 
    List.length (List.filter (fun l -> match l with 
      | Some _ -> true 
      | None -> false) lst) > 0 
    && List.length lst > 1
  in

(* This function takes the input to items_list and determines if the input
   still needs further parsing                                              *)
  let parse_fin (silst:((item list*symbol list*symbol list)*State.t) list) 
      : bool = 
    List.length (List.filter (fun ((i,su,sv),s) -> 
      List.length su = 1 && List.hd su = List.hd (List.rev !symbols)) silst) 
    = List.length silst
  in

(* This function takes the unvisited list of symbols from the input string,
   the visited list of symbols in the input string, the current state that
   the finite-state machine is in, the current list of reduced items, and
   the list of transitions, and then parses the unvisited list of symbols
   unless an ambiguous state is reached.  Either when an ambiguous state is
   reached or when the symbol list is fully processed, the function returns
   an option of the update item list, unvisited symbol list, visited symbol
   list, and the state at which the finite-state machine stopped.           *)
  let rec state_list_rec (unv : symbol list) (v : symbol list) (st : State.t) 
      (ilst : item list) (tlst: trans list) : 
      ((item list*symbol list*symbol list)*State.t) option =
    if (List.hd unv)= List.hd (List.rev !symbols)
        && (List.length unv) = 1 then Some ((ilst,unv,[]),state1)
    else 
      try 
        let (st1,st2,sym) = List.find (
          fun x -> 
            let (s1,s2,sy)=x in 
            ((State.equal s1 st) && (sy = (List.hd unv)))) tlst
        in
        if is_ambiguous (accepting_state st2) then Some ((ilst, unv, v),st2)
        else
          match unamb_accepting_state st2 with
            | None -> 
                state_list_rec (List.tl unv) ((List.hd unv)::v) st2 ilst tlst 
            | Some (i,l) -> 
                state_list_rec (List.append (List.rev (sublist v (l-1)))
                (i.lhs::(List.tl unv))) [] state1 (i::ilst) tlst
      with Not_found -> None
  in

(* This function takes the current list of reduced items, the list of
   unvisited symbols, the list of visited symbols, and the current state
   and if the list of unvisited symbols is not equal to the initial symbol
   then the function iterates over each item in the current state and
   creates a copy of the input, modifying it as needed if the current
   item requires a reduction                                                *)
  let expand_si (input:((item list*symbol list*symbol list)*State.t) option) 
      : ((item list*symbol list*symbol list)*State.t) list = 
    match input with
      | None -> []
      | Some ((il,slu,slv),s) ->
          if List.hd slu = List.hd (List.rev !symbols) && List.length slu = 1
            then [((il,slu,slv),s)]
          else List.fold_right (
            fun i r-> 
              if i.post = [] then 
                 (((i::il),List.append (List.rev (sublist slv 
                 ((List.length i.pre)-1))) (i.lhs::(List.tl slu)),[]),state1)::r
              else
                 ((il,List.tl slu,(List.hd slu)::slv),s)::r) 
            (State.elements s) []
  in

(* This function determines whether the input has been fully parsed, and if
   not, runs the input through the state_list_rec and expand_si functions
   defined above.                                                           *)
  let rec items_list (silst:((item list*symbol list*symbol list)*State.t) list)
      (tlst : trans list) : ((item list*symbol list*symbol list)*State.t) list =
    if parse_fin silst then silst
    else
      let list1 = (List.map (fun ((i,su,sv),st) -> 
          state_list_rec su sv st i tlst) silst) in
      let list2 = (List.fold_right (fun l1 r-> (expand_si l1) @ r) list1 []) in
      items_list (unique list2) tlst
  in

(* This portion of the file attempts to parse the input string from above and
   if the string is valid according to the grammar, prints every list of 
   possible parsings of the string along with structure of the parse.       *)
  try 
    let output = items_list [(([],to_parse,[]),state1)] ts in
    print_string "\n" ;

    match output with
      | [] ->
        print_string "The input string cannot be produced by the provided 
                      grammar.\nPlease try again: " ; 
        parse (read_line ())
      | _ -> 
        List.iter (fun ((i,su,sv),st) -> 
          print_items i; print_string "\n"; 
          print_string (otp_to_string i); print_string "\n") 
        output ;

    print_string "\nNew input string: " ; parse (read_line ())

  with Failure "hd" -> 
    print_string "\nThe input string cannot be produced by the provided grammar.
                  \nPlease try again: " ;
    parse (read_line ())
;;

let _ = parse input
