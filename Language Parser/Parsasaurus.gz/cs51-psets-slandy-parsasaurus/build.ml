(******************************************************************************

Filename: build.ml

Authors: Brooke Carter, Alec Guzov, Stephen Landy, and Dan Zangri

Description: 1) Reads in the grammar file, 2) builds the grammar map, and
     3) builds the finite state machine

******************************************************************************)

open Types

(* This list stores the unique set of symbols (both nonterminals and terminals 
   in the grammar                                                            *)
let symbols = ref []

(* This list stores the unique set of nonterminal symbols in the grammar     *)
let nonterminals = ref []

(* This function checks if a symbol is a nonterminal                         *)
let is_terminal (t: symbol) : bool = not (List.mem t !nonterminals)

(* This function behaves in the standard way                                 *)
let reduce f u l = List.fold_right f l u

(* This function splits the string s into a list of substrings, where the 
   substrings are the portions of the string between each occurence of sub   *)
let split (sub : string) (s : string) : 
    string list = Str.split (Str.regexp_string sub) s

(* This function adds a symbol to a list of symbols if the symbol is not
   already present in the list                                               *)
let add_symbol (sym : symbol) (list : symbol list ref) : unit =
  if not (List.mem sym !list) then list := sym :: !list

(* This function takes a list of symbols and inserts the unique elements
   into the symbol list ref defined at the top of the function               *)
let add_symbols (list : symbol list) : unit =
  match list with
    | [] -> failwith "Invalid grammar: epsilon transition."
    | _ -> 
      List.iter (fun s -> 
        if s = "" then 
          failwith "Invalid grammar: consecutive spaces or trailing whitespace."
        else add_symbol s symbols) list

(* This function takes in a string and a grammar map, and inserts the grammar
   rule in the string into the map                                           *)
let line_to_map (line:string) (m: 'a GramMap.t) : 'a GramMap.t =

  let lhs , rhses =
    match (split " ->" line) with
      | lhs::rhs::[] -> lhs , List.map (split " ") (split "|" rhs)
      | _ -> failwith "Invalid grammar: use one '->' per line." in

  if List.length (split " " lhs) <> 1 || lhs = "  " then 
    failwith "Invalid grammar: use one symbol prior to '->'."
  else (add_symbol lhs symbols ; add_symbol lhs nonterminals) ;

  List.iter add_symbols rhses ;

  if GramMap.mem lhs m then
    let old = GramMap.find lhs m in
    GramMap.add lhs (rhses @ old) (GramMap.remove lhs m)
  else GramMap.add lhs rhses m

(* This function takes in the name of the text file that stores the rules
   of the grammar and iterates through the rules of the grammar, inputting
   each rule into the grammar map                                            *)
let create_map (filename:string) : symbol list list GramMap.t =
  let lines = ref [] in
  let channel = open_in filename in
  let _ = try
            while true do lines := input_line channel :: !lines done
          with End_of_file -> close_in channel in
  if !lines = [] then failwith "Invalid grammar: file is empty."
  else reduce line_to_map GramMap.empty !lines

(* This function takes in a symbol and a grammar map, and searches for the
   symbol in the grammar map if the symbol is a nonterminal, returning the
   right-hand side of the grammar rule for the nonterminal                   *)
let rhs (t:symbol) (m: 'a GramMap.t) : symbol list list =
  match is_terminal t with
    | true -> []
    | false -> GramMap.find t m

(* This function takes in the grammar map, an item in a state of our finite-
   state machine, and a state of our finite-state machine, and returns a state
   of all items that can be reached from a given item without needing to 
   read in a new symbol from the input string                                *)
let rec expand (m:'a GramMap.t) (i:item) (st:State.t) : State.t =
  if is_terminal (i.lhs) then failwith "Terminal on lhs"
  else
    match i.post with
      | [] -> State.add i st
      | t::_ -> 
        if State.mem i st then st 
        else
          reduce (fun x -> expand m {lhs = t; pre = []; post = x}) 
              (State.add i st) (rhs t m)

(* This function takes in a grammar map, a symbol, an item, and a state, and
   if the item is not a terminal nor the portion of the item to the right of
   the cursor is empty, and the portion of the item's right-hand side that is
   to the left of the cursor is equal to the input symbol, then the cursor is
   moved over one symbol in the item and the expand function is then called
   upon that new item, which is the referre-to "kernel"                      *)
let create_kernel (m: 'a GramMap.t) (t:symbol) (i:item) (v:State.t) : State.t =
  if is_terminal (i.lhs) then failwith "Terminal on lhs"
  else
    match i.post with
      | [] -> v
      | x::rest ->
        if x = t then expand m {lhs = i.lhs; pre = i.pre@[x]; post = rest} v 
        else v

(* This function takes in the grammar map, an unvisited state, a symbol,
   a three tuple of the set of states, list of transitions, and set
   of unvisited states, and expands the items in the unvisited state,
   returning the updated set of states, list of transitions, and
   unvisited states                                                         *)
let create_v (m: 'a GramMap.t) (u:State.t) (t:symbol) (big_s,big_t,big_u) : 
    (StateSet.t*trans list*StateSet.t) =
  let v = State.fold (create_kernel m t) u State.empty in
  if State.is_empty v then (big_s,big_t,big_u)
  else if StateSet.mem v big_s then (big_s,(u,v,t)::big_t,big_u)
  else (StateSet.add v big_s,(u,v,t)::big_t,StateSet.add v big_u)

(* This function takes in the grammar map, the set of processed states, the
   list of transitions, and the set of unvisited states, and returns an
   updated tuple of processed states, list of transitions, and unvisited
   states once all of the unvisited states' items have been expanded        *)
let rec process (m:'a GramMap.t) (big_s:StateSet.t) 
    (big_t:trans list) (big_u:StateSet.t) : StateSet.t*trans list*StateSet.t =
  if StateSet.is_empty big_u then (big_s,big_t,big_u) else
    let u = StateSet.max_elt big_u in
    let (new_s,new_t,new_u) = reduce (create_v m u) 
                              (big_s,big_t,StateSet.remove u big_u) !symbols in
    process m new_s new_t new_u

(* This function takes in the initial symbol of the grammar and the grammar
   map and returns the initial state of the finite-state machine            *)
let initial_state (initial_symbol:symbol) (m:'a GramMap.t) : State.t =
  match rhs initial_symbol m with
    | [] -> failwith "Empty initial state"
    | list -> 
      reduce (fun x -> expand m {lhs = initial_symbol; pre = []; post = x}) 
          State.empty list

(* This function takes in the grammar map and creates the finite state 
   machine from map, and returns the initial state, the set of states in
   the finite state machine, and the list of transitions                    *)
let build_lookup (m:'a GramMap.t) =
  let state1 = initial_state (List.hd (List.rev !symbols)) m in
  let s,t,u = StateSet.singleton state1 , [] , StateSet.singleton state1 in 
  let (s',t',_) = process m s t u in (state1,s',t')
