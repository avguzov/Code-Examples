(******************************************************************************

Filename: ptree.ml

Authors: Brooke Carter, Alec Guzov, Stephen Landy, and Dan Zangri

Description: Contains the functions which are needed for printing the input
    string according to the structure of its parse.

******************************************************************************)

open Types
open Print
open Build


(* This function removes the first occurence of the input in the item list
   if it exists and returns the modified list, but if the item is not
   present then the function simmply returns the item list.                  *)
let remove_first (i : item) (ilst : item list) : item list =
  let rec remrec (olst : item list) (it : item) (rlst : item list) =
    match rlst with
    | [] -> olst
    | hd::tl -> (if it.lhs=hd.lhs then olst@tl 
                   else remrec (List.rev (hd::(List.rev olst))) it tl)
  in
remrec [] i ilst
;; 

(* This function takes an item list and a symbol and returns an option that
   indicates if the symbol was found on the left hand side of any of the
   items in the item list with an option of that item.                       *)    
let isearch (ilst : item list) (sy : symbol) : item option*item list =
  try 
    let it = (List.find (fun x -> x.lhs=sy) ilst) in
    (Some (it), remove_first (it) ilst)
  with Not_found ->
    (None, ilst)

(* This function takes a symbol list and returns whether a symbol list has
   more than one nonterminal symbol.                                         *)
let twonter (slst : symbol list) : bool =
  let rec tnt_help (n : int) (nslst : symbol list) =
    if n > 1 then true
    else
      match nslst with
      | [] -> false
      | hd::tl -> if (not(is_terminal hd)) then tnt_help (n+1) tl 
                  else tnt_help n tl
  in
tnt_help 0 slst

(* This function takes an item list that represents the reduced items and 
   reproduces the input string according to the structure of the pars        *)
let otp_to_string (ilst : item list) : string =
  let rec otp_help (str : string) (hold : string) (wait : int) (lst : item list)
   (unsy : symbol list) (store : symbol list list) =
    match unsy with
    | [] -> (match lst with
             | [] -> str
             | hd::tl -> let nst=(str^hd.lhs^"(") in
                         otp_help nst hold wait tl hd.pre [[]])
    | hd::tl ->
         (if is_terminal hd then
            (if (tl=[]) then
               let ex = ((List.length store) > 0) in
               let wb = (wait > 0) in
               otp_help (str^hd^")"^(if wb then "" else hold)) 
                (if wb then hold else "") (if wb then (wait-1) else wait) lst 
                (if ex then List.hd store else []) 
                (if ex then List.tl store else [])
             else
               otp_help (str^hd) hold wait lst tl store)
          else
            let nhold = if tl=[] then (hold ^ ")") else hold in
            match (isearch lst hd) with
            | (Some(nit),nlst) ->
                  let nwait = if (twonter nit.pre) && (tl=[]) 
                  then (wait+1) else (wait) in 
                  otp_help (str ^ nit.lhs ^ "(") nhold nwait nlst (nit.pre) 
                  (if (tl=[]) then store else (tl::store)) 
            | (None,nlst) -> otp_help (str^hd) nhold wait nlst tl (store))
   in
otp_help "" "" 0 ilst [] [[]]
