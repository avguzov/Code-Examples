(******************************************************************************

Filename: print.ml

Authors: Brooke Carter, Alec Guzov, Stephen Landy, and Dan Zangri

Description: Contains the definitions for all of the functions that print
    various elements of the program, and was mainly used for debugging
    purposes.

******************************************************************************)

open Build
open Types

(* This function prints a symbol                                             *)
let print_symbol (t: symbol) : unit = print_string t

(* This function prints a list of symbols                                    *)
let rec print_symbols (lst: symbol list) : unit =
  match lst with
    | [] -> ()
    | hd::[] -> print_symbol hd;
    | hd::tl -> print_symbol hd; print_string " "; print_symbols tl

(* This function prints a list of symbol lists                               *)
let rec print_symbolses (lst: symbol list list) : unit =
  match lst with
    | [] -> ()
    | hd::[] -> print_symbols hd
    | hd::tl -> print_symbols hd; print_string " | "; print_symbolses tl

(* This function prints every symbol in the input symbol list along with
    the values that the symbol corresponds to                                *)
let print_map (m: symbol list list GramMap.t) (ts: symbol list) : unit =
  print_string "\n\n";
  let find_and_print m t =
    print_symbol t; print_string " -> "; 
    if GramMap.mem t m then print_symbolses (GramMap.find t m);
    print_string "\n"
  in List.iter (find_and_print m) ts; print_string "\n"

(* This function prints an item                                              *)
let print_item ({lhs = t; pre = pre; post = post}) : unit =
  print_symbol t; print_string " -> ";
  print_symbols pre; print_string "*";
  print_symbols post

(* This function prints a list of items                                      *)
let print_items (lst: item list) : unit =
  List.iter (fun i -> print_item i; print_string "\n") (List.rev lst)

(* This function prints out each item in the input state                     *)  
let print_state (st: State.t) : unit = 
  State.iter (fun i -> print_item i; print_string "\n") st

(* This function prints out each item in each state within the input set     *)
let print_states (big_s : StateSet.t) : unit =
  print_string "\n{\n";
  StateSet.iter (fun st -> print_state st; print_string "-----\n") big_s;
  print_string "}\n\n"

(* This functions prints a random item within the input state                *)
let print_single (st:State.t) : unit =
  print_item (State.choose st)

(* This function prints every string in the input list of strings            *)  
let print_strings (lst:string list) : unit =
  List.iter (fun s -> print_string s; print_string "\n") lst

(* This function prints out a random item from each input state as well as
   the input symbol                                                          *)
let print_trans ((u,v,t):State.t*State.t*symbol) : unit =
  print_string "("; print_single u; print_string " ...), ";
  print_symbol t; print_string " -> ";
  print_string "("; print_single v; print_string " ...)\n"

(* This function prints every trans in the input list of transes             *)
let print_transes (big_t:trans list) : unit =
  print_string "\n";
  List.iter print_trans big_t;
  print_string "\n"

(* This function prints every state in the input set of states as well as every
   trans in the input trans list                                             *)
let print_lookup (big_s:StateSet.t) (big_t: trans list) : unit=
  print_string "States:\n\n"; print_states big_s;
  print_string "Transitions:\n\n"; print_transes big_t
